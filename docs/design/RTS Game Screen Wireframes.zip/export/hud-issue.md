# HUD: replace corner panels with the map-first floating HUD

**Labels:** `ui`, `app`, `enhancement`
**Package:** `@lions/app` (`packages/app/src/ui/*`, `theme.css`) — shell only, no sim changes (invariant 4 holds: HUD renders what the sim reports)
**Design spec:** `RTS HUD Spec.dc.html` (4 states × 2 resolutions), explorations in `RTS HUD Wireframes.dc.html` (option 1g → turn 2)

## Why

The current HUD (`hud.ts` + `production.ts`) stacks three `rl-panel` sections in the corners: a 300px briefing top-left, `--rail-left` production bottom-left, `--rail-right` selection card bottom-right. Together they cover ~35% of a 1440×900 viewport, the briefing hides the map corner the player pans toward most, and reinforcements are text buttons (`Rifle Squad (120)`) with no image. The floating design keeps the map visible, puts orders where the selection is, and uses the unit sprites the art pipeline already produces.

## Target layout (edge-anchored, holds at 1440×900 and 1920×1080)

All offsets 8px from the frame edge. Panel chrome is unchanged: `rgba(20,21,15,.92)` fill, `1px solid #363B39` hairline, no radius, no shadow.

| Region | Position | Contents |
|---|---|---|
| Top strip | `left:0;right:0;top:0;height:30px` | brigade mark · mission name · `ROE` score (tone-coloured) · primary objective + hold clock · `+N secondary` · right side: `▣ logistics +rate/min` · `◎ intel` · `▼ N pinned` · `⚑ N broken` (only when > 0) · pause/1×/2× · campaign-map link · mute |
| Hold clock | `top:38px`, centred | Big Shoulders 34px/800. `CONTESTED` / `NOBODY HOLDING` appended; red + `rl-pulse` when contested (same logic as `renderClock()`) |
| Commander | `top:40px;left:8px` | 60×60 portrait frame. On a story beat expands into a 520px bar: name + `n / total`, quote, progress hairline, ◂ ▸ paging. Collapses after the beat |
| Group tabs | `top:40px;right:8px` | one chip per control group (`ctrl+1–9`), coloured per group |
| Event feed | `bottom:150px`, centred right of dock (`left:calc(50% + 70px)`), 560px, text-shadow, no panel | replaces `.rl-notices`; max 4 lines, tone-coloured, self-clearing (keep the 9s `leave()`) |
| Bottom centre | `bottom:8px`, same x as feed | **nothing selected:** one-line controls hint. **selected:** order button row above the selection cluster (below) |
| Reinforcements dock | `left:8px;bottom:8px`, label `Reinforcements · B` above | 5×2 grid of 60×60 tiles: 8 units + `◎ sweep 30` + `✸ strike 60` |
| Minimap | `right:8px;bottom:8px`, 210×210 | viewport rectangle (lime), contacts red, friendlies blue, objectives amber diamonds, story markers lime diamonds |

Projected fire (`projectedFireHtml()`) moves out of the briefing onto the cursor: a small panel at `hover + 36px` listing per-weapon P(hit) with the two worst penalties, `cannot penetrate` in red. Cap rows at 6 as today.

## Selection cluster

**Multi-select:** a row of 150px chips, one per unit type in the selection (`sim.unitTypes[typeIdx]` grouped). Chip = 40px sprite (`assets/sprites/<UNIT>/idle` frame, `image-rendering:pixelated`) · role badge (`ROLE_GLYPH[roleBucket(type)]` as SVG, same shapes as `vite-plugin-cursors.ts`) · name · `×count` · hp track (`rl-fill-good/warn/bad`) · one status line (`1 PINNED` / `holding` / `APS 3/4`). Lime border marks the focused sub-group (tab cycles).

**Single unit:** a 460px card: 72px sprite frame with badge · name (Big Shoulders 19px) · veterancy `★` · `hp / max` + track · condition line (existing `flags[]` logic) · two columns: **Armament** (existing weapon rows) and **Capabilities** (existing `caps[]`).

**Order row** (above chips/card): buttons `⟶ Attack-move A` · `■ Halt H` · `◌ Smoke F` · `⤓ Load G` · `⤒ Unload U`. Show only orders at least one selected unit can perform; lime border+text when the order is the armed/highlighted one; 45% opacity when the selection has the capability but it currently does nothing (e.g. Unload with nobody aboard). Show `0/8` capacity next to Load for transports. Buttons dispatch the same intents as the keys in `input/intents.ts`.

## Dock tiles (`production.ts`)

Tile = 56px sprite + cost badge bottom-right (`#E0B87A`). States:
- **queued:** lime 3px progress bar along the bottom, `14s` countdown top-left (`ticksLeft / TICKS_PER_SECOND`)
- **can't afford:** tile 45% opacity, cost badge red
- **locked** (`buildBlockedReason()` non-null): sprite grayscale 35% + reason text (`ROE ≥ 90`, `locked`)
- **hover:** border `#E0B87A` + tooltip panel above the dock: name · `cost · build time` · role badge + doctrine tags · one line of description (new optional `blurb` field on `BuildableUnit`, sourced from the unit JSON)
- **support tiles:** `◎ sweep 30` / `✸ strike 60`, blue border when affordable, 45% when not; armed state = lime border (existing `data-armed`)

Remove the `rl-queue` list; the tile progress replaces it.

## Type & tokens

- Body: **Barlow 400/600, 12px, line-height 1.5** (add to `theme.css`; replaces IBM Plex Mono for body text)
- Headers/numerals: **Big Shoulders Display 800**, uppercase, `letter-spacing:.06em` (15px band titles, 19px card title, 34px clock); labels 10px/600 `letter-spacing:.18em` `#C3C7C4`
- Tones unchanged: good `#6B8A4A` · warn `#E8C33A` · bad `#D93A2B` · hot `#FFB43C` · info `#A9C4D1` · live `#B8FF5A` · dim `#8E9491` · text `#F2E8D5` · cost `#E0B87A`
- New tokens: `--hud-strip-h: 30px`, `--tile: 60px`, `--chip-w: 150px`, `--card-w: 460px`, `--minimap: 210px`

## Implementation notes

1. `hud.ts`: split `brief` into `strip` (top) + `commander` + `feed`; `missionHtml()` content moves to the strip, `controlsHtml()` to bottom-centre, `projectedFireHtml()` to a cursor-following panel fed by `hoverEntity()` position.
2. `hud.ts` `renderCard()`: branch on `sel.length`; build chips by grouping `typeIdx`. Keep the `rl-enter` animation on first show.
3. `production.ts`: tiles need the sprite URL — extend `BuildableUnit` with `sprite: string`; resolve from the mesh/sprite catalogue in `main.ts`.
4. Minimap and control-group chips are new; group state already lives in `input/intents.ts`.
5. Commander bar: driven by mission `notes`/`briefingBeats()` in `loading.ts` — a beat with a speaker opens the bar; the existing `note()` path keeps feeding the feed.
6. Keep 4 Hz rebuild cadence (`tickN % 5`).

## Acceptance

- [ ] Every element of the 4 spec states renders at 1440×900 and 1920×1080 with nothing clipped
- [ ] No `rl-panel` remains on the mission screen except the projected-fire and dock tooltips
- [ ] Dock tiles show queue progress, affordability, lock reason, hover tooltip
- [ ] Order row shows only applicable orders and dispatches the same intents as hotkeys
- [ ] Clock/ROE/pinned/broken punctuation (`flash`, `rl-pulse`) still fires
- [ ] `pnpm test` passes; no sim imports beyond `fx`, `TICKS_PER_SECOND`, `Sim` type

## Open items (separate tickets)

- Commander portrait render (currently hatched placeholder)
- Dedicated unit portrait icons — idle sprites face one direction and read poorly at 40px
- Order glyph SVG set (currently Unicode)
